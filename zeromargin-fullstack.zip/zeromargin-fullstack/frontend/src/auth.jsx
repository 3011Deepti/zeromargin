import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { io } from 'socket.io-client';
import { api, API_URL, getToken } from './api';

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!getToken());
  const [socket, setSocket] = useState(null);
  const [unread, setUnread] = useState(0);

  const refreshUnread = useCallback(() => api('/notifications').then((d) => setUnread(d.unread)).catch(() => {}), []);

  useEffect(() => {
    if (!getToken()) return;
    api('/auth/me').then((d) => setUser(d.user)).catch(() => localStorage.removeItem('zm_token')).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!user) { setSocket(null); setUnread(0); return; }
    const s = io(API_URL, { auth: { token: getToken() } });
    s.on('notification', () => setUnread((n) => n + 1));
    setSocket(s);
    refreshUnread();
    return () => s.disconnect();
  }, [user?._id, refreshUnread]);

  const login = (data) => { localStorage.setItem('zm_token', data.token); setUser(data.user); };
  const logout = () => { localStorage.removeItem('zm_token'); setUser(null); };
  const reloadUser = () => api('/auth/me').then((d) => setUser(d.user));

  return <Ctx.Provider value={{ user, loading, login, logout, socket, unread, setUnread, reloadUser }}>{children}</Ctx.Provider>;
}
