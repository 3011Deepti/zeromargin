export const API_URL = (import.meta.env.VITE_API_URL || 'http://localhost:5000').replace(/\/$/, '');

export const getToken = () => localStorage.getItem('zm_token');

export async function api(path, { method = 'GET', body, params } = {}) {
  const qs = params ? '?' + new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null)) : '';
  const headers = {};
  if (body) headers['Content-Type'] = 'application/json';
  if (getToken()) headers.Authorization = `Bearer ${getToken()}`;
  let res;
  try {
    res = await fetch(`${API_URL}/api${path}${qs}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch {
    throw new Error('Cannot reach the server. Please try again in a moment.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || 'Request failed');
  return data;
}

export async function uploadImage(file) {
  const fd = new FormData();
  fd.append('image', file);
  const res = await fetch(`${API_URL}/api/upload`, { method: 'POST', headers: { Authorization: `Bearer ${getToken()}` }, body: fd });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || 'Upload failed');
  return data.url;
}

export const CATEGORIES = ['Electronics', 'Clothing', 'Furniture', 'Books', 'Home & Kitchen', 'Sports & Fitness', 'Other'];
export const CONDITIONS = { new: 'New', like_new: 'Like new', good: 'Good', fair: 'Fair' };
export const inr = (n) => '₹' + Number(n).toLocaleString('en-IN');
export const trustOf = (u) => {
  const total = (u?.verifiedTrades || 0) + (u?.disputedTrades || 0);
  return total ? Math.round((u.verifiedTrades / total) * 100) : null;
};
