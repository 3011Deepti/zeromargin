import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, inr } from '../api';
import { useAuth } from '../auth.jsx';
import { ErrorMsg, Loading } from '../components/Status.jsx';

const LABEL = { placed: 'Awaiting seller', accepted: 'Accepted: arrange hand-off', handed_off: 'Handed off: awaiting buyer confirmation', completed: 'Completed & verified', disputed: 'Disputed', cancelled: 'Cancelled' };

export default function Orders() {
  const { user, reloadUser } = useAuth();
  const [orders, setOrders] = useState(null);
  const [err, setErr] = useState('');
  const load = () => api('/orders/mine').then(setOrders).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []);

  const act = async (id, action, body) => {
    setErr('');
    try { await api(`/orders/${id}/${action}`, { method: 'PATCH', body }); await load(); reloadUser(); } catch (e) { setErr(e.message); }
  };
  if (!orders) return <Loading />;

  return (
    <div className="wrap section">
      <h1>Orders</h1>
      <p className="muted">Your trust score: {user.trustScore === null ? 'not yet rated: complete a verified hand-off to start' : `${user.trustScore}%`}</p>
      <ErrorMsg>{err}</ErrorMsg>
      {orders.length === 0 && <div className="empty">No orders yet. <Link className="textlink" to="/browse">Find something</Link>.</div>}
      <div className="list">
        {orders.map((o) => {
          const isSeller = String(o.seller._id) === String(user._id);
          const other = isSeller ? o.buyer : o.seller;
          return (
            <div key={o._id} className="card pad">
              <div className="row between">
                <div>
                  <Link to={`/listing/${o.listing?._id}`} className="textlink"><b>{o.listing?.title || 'Removed listing'}</b></Link>
                  <div className="small muted">{isSeller ? 'Buyer' : 'Seller'}: {other.name} · {inr(o.price)} · 0% commission</div>
                </div>
                <span className={`status s-${o.status}`}>{LABEL[o.status]}</span>
              </div>
              <div className="row actions">
                {isSeller && o.status === 'placed' && <button className="btn btn-sm" onClick={() => act(o._id, 'accept')}>Accept</button>}
                {isSeller && o.status === 'accepted' && <button className="btn btn-sm" onClick={() => act(o._id, 'handoff')}>I handed it over</button>}
                {!isSeller && o.status === 'handed_off' && (<>
                  <button className="btn btn-sm" onClick={() => act(o._id, 'verify', { verified: true })}>Yes, I received it</button>
                  <button className="btn btn-sm btn-danger" onClick={() => act(o._id, 'verify', { verified: false })}>Report a problem</button>
                </>)}
                {['placed', 'accepted'].includes(o.status) && <button className="btn btn-ghost btn-sm" onClick={() => act(o._id, 'cancel')}>{isSeller && o.status === 'placed' ? 'Decline' : 'Cancel'}</button>}
                {o.status !== 'cancelled' && !isSeller && <ChatLink listingId={o.listing?._id} />}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ChatLink({ listingId }) {
  const nav = useNavigate();
  const open = async () => { const c = await api('/chat/conversations', { method: 'POST', body: { listingId } }); nav(`/chat/${c._id}`); };
  return listingId ? <button className="btn btn-ghost btn-sm" onClick={open}>Chat</button> : null;
}
