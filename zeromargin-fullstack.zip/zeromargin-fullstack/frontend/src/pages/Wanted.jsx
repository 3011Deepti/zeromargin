import { useEffect, useState } from 'react';
import { api, inr, CATEGORIES } from '../api';
import { useAuth } from '../auth.jsx';
import { Link } from 'react-router-dom';
import { ErrorMsg } from '../components/Status.jsx';

export default function Wanted() {
  const { user } = useAuth();
  const [list, setList] = useState([]);
  const [f, setF] = useState({ title: '', maxPrice: '', category: '' });
  const [err, setErr] = useState('');
  const [ok, setOk] = useState('');
  const load = () => api('/wanted').then(setList).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault(); setErr(''); setOk('');
    try { await api('/wanted', { method: 'POST', body: { ...f, category: f.category || undefined } }); setF({ title: '', maxPrice: '', category: '' }); setOk('Posted! Matching sellers have been notified, and we will alert you when a match appears.'); load(); }
    catch (e2) { setErr(e2.message); }
  };
  const remove = async (id) => { await api(`/wanted/${id}`, { method: 'DELETE' }); load(); };

  return (
    <div className="wrap section">
      <h1>Wanted items</h1>
      <p className="muted">Can’t find it? Post a Wanted Item alert and matching sellers are notified instantly. You’ll be notified when someone lists a match.</p>
      {user ? (
        <form className="form inline" onSubmit={submit}>
          <input required placeholder="What do you need? e.g. second-hand scientific calculator" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <input required type="number" min="1" placeholder="Max price ₹" value={f.maxPrice} onChange={(e) => setF({ ...f, maxPrice: e.target.value })} />
          <select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}><option value="">Auto category</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
          <button className="btn btn-sm">Post alert</button>
        </form>
      ) : <p><Link to="/login" className="textlink">Log in</Link> to post a wanted item.</p>}
      <ErrorMsg>{err}</ErrorMsg>
      {ok && <div className="okmsg">{ok}</div>}
      <div className="list">
        {list.length === 0 && <div className="empty">No wanted items yet.</div>}
        {list.map((w) => (
          <div key={w._id} className="card pad row between">
            <div><b>{w.title}</b><div className="small muted">{w.category} · up to {inr(w.maxPrice)} · by {w.user?.name}</div></div>
            {user && String(user._id) === String(w.user?._id) ? <button className="btn btn-ghost btn-sm" onClick={() => remove(w._id)}>Remove</button> : <Link className="btn btn-ghost btn-sm" to={`/sell`}>I have this</Link>}
          </div>
        ))}
      </div>
    </div>
  );
}
