import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../api';
import ListingCard from '../components/ListingCard.jsx';
import TrustBadge from '../components/TrustBadge.jsx';
import { Loading, ErrorMsg } from '../components/Status.jsx';

export default function Profile() {
  const { id } = useParams();
  const [d, setD] = useState(null);
  const [err, setErr] = useState('');
  useEffect(() => { api(`/users/${id}`).then(setD).catch((e) => setErr(e.message)); }, [id]);
  if (err) return <div className="wrap section"><ErrorMsg>{err}</ErrorMsg></div>;
  if (!d) return <Loading />;
  return (
    <div className="wrap section">
      <h1>{d.user.name}</h1>
      <p className="muted">{[d.user.college, d.user.city].filter(Boolean).join(' · ')} · Member since {new Date(d.user.createdAt).toLocaleDateString()}</p>
      <TrustBadge user={d.user} full />
      <h2 style={{ marginTop: 32 }}>Listings</h2>
      {d.listings.length ? <div className="grid4">{d.listings.map((i) => <ListingCard key={i._id} item={{ ...i, seller: d.user }} />)}</div> : <div className="empty">No active listings.</div>}
    </div>
  );
}
