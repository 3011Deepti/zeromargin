import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api, CATEGORIES, CONDITIONS } from '../api';
import ListingCard from '../components/ListingCard.jsx';
import { Loading, ErrorMsg } from '../components/Status.jsx';

export default function Browse() {
  const [sp, setSp] = useSearchParams();
  const [data, setData] = useState(null);
  const [err, setErr] = useState('');
  const [q, setQ] = useState(sp.get('q') || '');
  const get = (k) => sp.get(k) || '';

  const update = (k, v) => {
    const n = new URLSearchParams(sp);
    v ? n.set(k, v) : n.delete(k);
    if (k !== 'page') n.delete('page');
    setSp(n);
  };

  useEffect(() => {
    setData(null);
    api('/listings', { params: Object.fromEntries(sp) }).then(setData).catch((e) => setErr(e.message));
  }, [sp]);

  return (
    <div className="wrap section">
      <h1>Browse</h1>
      <form className="filters" onSubmit={(e) => { e.preventDefault(); update('q', q.trim()); }}>
        <input placeholder="Search items…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={get('category')} onChange={(e) => update('category', e.target.value)}>
          <option value="">All categories</option>
          {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </select>
        <select value={get('condition')} onChange={(e) => update('condition', e.target.value)}>
          <option value="">Any condition</option>
          {Object.entries(CONDITIONS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
        <input type="number" min="0" placeholder="Min ₹" defaultValue={get('minPrice')} onBlur={(e) => update('minPrice', e.target.value)} />
        <input type="number" min="0" placeholder="Max ₹" defaultValue={get('maxPrice')} onBlur={(e) => update('maxPrice', e.target.value)} />
        <select value={get('sort')} onChange={(e) => update('sort', e.target.value)}>
          <option value="">Newest</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option>
        </select>
        <button className="btn btn-sm">Search</button>
      </form>
      <ErrorMsg>{err}</ErrorMsg>
      {!data && !err && <Loading />}
      {data && (data.items.length === 0 ? (
        <div className="empty">No items match. Try different filters, or <a className="textlink" href="/wanted">post a Wanted Item</a> and get notified when a seller lists it.</div>
      ) : (
        <>
          <p className="muted small">{data.total} item{data.total !== 1 && 's'}</p>
          <div className="grid4">{data.items.map((i) => <ListingCard key={i._id} item={i} />)}</div>
          {data.pages > 1 && (
            <div className="pager">
              <button className="btn btn-ghost btn-sm" disabled={data.page <= 1} onClick={() => update('page', data.page - 1)}>← Prev</button>
              <span className="muted small">Page {data.page} of {data.pages}</span>
              <button className="btn btn-ghost btn-sm" disabled={data.page >= data.pages} onClick={() => update('page', data.page + 1)}>Next →</button>
            </div>
          )}
        </>
      ))}
    </div>
  );
}
