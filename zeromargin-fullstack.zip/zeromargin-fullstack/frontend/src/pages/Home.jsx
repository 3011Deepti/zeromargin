import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, inr } from '../api';
import ListingCard from '../components/ListingCard.jsx';

const STEPS = [
  ['Seller lists item', 'Category is auto-tagged from your title.'],
  ['Buyer searches & filters', 'By category, price, condition and city.'],
  ['Direct order placed', 'No checkout fee, no commission.'],
  ['In-app chat', 'Real-time chat. Phone numbers stay private.'],
  ['Hand-off completed', 'Buyer confirms they received the item.'],
  ['Trust score updated', 'Verified hand-offs raise reputation.'],
];

export default function Home() {
  const [sale, setSale] = useState(5000);
  const [recent, setRecent] = useState([]);
  useEffect(() => { api('/listings', { params: { limit: 4 } }).then((d) => setRecent(d.items)).catch(() => {}); }, []);

  return (
    <>
      <section className="hero">
        <div className="wrap hero-in">
          <div>
            <p className="eyebrow">Peer-to-peer resale</p>
            <h1>Resale with <em>no middleman</em> tax.</h1>
            <p className="lead">ZeroMargin is a marketplace where sellers keep 100% of the sale and buyers pay the lowest organic price. Trust is earned through verified hand-offs, not paid for.</p>
            <div className="cta">
              <Link to="/browse" className="btn">Browse items</Link>
              <Link to="/sell" className="btn btn-ghost">Sell something</Link>
            </div>
          </div>
          <div className="zero" aria-hidden="true"><span>0%</span><small>commission</small></div>
        </div>
      </section>

      <section className="wrap section">
        <h2>The middleman tax</h2>
        <p className="muted">Paid platforms take 10–20% of every sale before processing fees. “Free” platforms have no trust checks, so scams are common. Nothing good sits in the middle.</p>
        <div className="calc card">
          <label>
            If you sell for <strong>{inr(sale)}</strong>
            <input type="range" min="500" max="50000" step="500" value={sale} onChange={(e) => setSale(+e.target.value)} />
          </label>
          <div className="calc-grid">
            <div><span className="muted small">Typical platform (10%)</span><b className="bad">You keep {inr(sale * 0.9)}</b></div>
            <div><span className="muted small">Typical platform (20%)</span><b className="bad">You keep {inr(sale * 0.8)}</b></div>
            <div className="good-box"><span className="small">ZeroMargin (0%)</span><b>You keep {inr(sale)}</b></div>
          </div>
          <p className="small muted">Illustrative: platform fee only, before processing charges.</p>
        </div>
      </section>

      <section className="band">
        <div className="wrap section">
          <h2>How a trade works</h2>
          <ol className="steps">
            {STEPS.map(([t, d], i) => (<li key={t}><span className="num">{i + 1}</span><div><b>{t}</b><p className="small muted">{d}</p></div></li>))}
          </ol>
        </div>
      </section>

      <section className="wrap section">
        <h2>Fixing the trust problem</h2>
        <div className="grid3">
          <div className="card pad"><h3>P2P trust scoring</h3><p className="muted">No central moderators. Reputation is earned through successful, verified hand-offs.</p><code className="formula">Trust = verified hand-offs ÷ completed orders</code></div>
          <div className="card pad"><h3>Smart matching</h3><p className="muted">Post a “Wanted Item” alert and matching sellers are notified instantly.</p><Link to="/wanted" className="textlink">See wanted items →</Link></div>
          <div className="card pad"><h3>Fair-pricing engine</h3><p className="muted">When you list, we read price trends and suggest a fair price so you don’t over- or under-price.</p></div>
        </div>
      </section>

      {recent.length > 0 && (
        <section className="wrap section">
          <div className="row between"><h2>Fresh listings</h2><Link to="/browse" className="textlink">View all →</Link></div>
          <div className="grid4">{recent.map((i) => <ListingCard key={i._id} item={i} />)}</div>
        </section>
      )}

      <section className="band">
        <div className="wrap section">
          <h2>Who it helps</h2>
          <div className="grid3">
            <div className="card pad"><h3>People</h3><p className="muted">College students, low-income households and eco-conscious buyers.</p></div>
            <div className="card pad"><h3>Economy</h3><p className="muted">Millions of dollars stay in local communities when fees disappear.</p></div>
            <div className="card pad"><h3>Environment</h3><p className="muted">Longer life for electronics, clothes and furniture, and less landfill.</p></div>
          </div>
        </div>
      </section>
    </>
  );
}
