import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api, inr, CONDITIONS } from '../api';
import { useAuth } from '../auth.jsx';
import TrustBadge from '../components/TrustBadge.jsx';
import { Loading, ErrorMsg } from '../components/Status.jsx';

export default function ListingDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const nav = useNavigate();
  const [item, setItem] = useState(null);
  const [img, setImg] = useState(0);
  const [err, setErr] = useState('');
  const [msg, setMsg] = useState('');

  useEffect(() => { api(`/listings/${id}`).then(setItem).catch((e) => setErr(e.message)); }, [id]);
  if (err && !item) return <div className="wrap section"><ErrorMsg>{err}</ErrorMsg></div>;
  if (!item) return <Loading />;

  const mine = user && String(user._id) === String(item.seller._id);
  const needLogin = () => { nav('/login', { state: { from: `/listing/${id}` } }); };

  const order = async () => {
    if (!user) return needLogin();
    setErr(''); setMsg('');
    try { await api('/orders', { method: 'POST', body: { listingId: id } }); nav('/orders'); } catch (e) { setErr(e.message); }
  };
  const chat = async () => {
    if (!user) return needLogin();
    try { const c = await api('/chat/conversations', { method: 'POST', body: { listingId: id } }); nav(`/chat/${c._id}`); } catch (e) { setErr(e.message); }
  };
  const remove = async () => {
    if (!confirm('Delete this listing?')) return;
    await api(`/listings/${id}`, { method: 'DELETE' }); nav('/browse');
  };

  const available = item.status === 'available';
  return (
    <div className="wrap section detail">
      <div>
        <div className="bigimg">{item.images?.[img] ? <img src={item.images[img]} alt={item.title} /> : <span className="thumb-ph big">{item.category[0]}</span>}</div>
        {item.images?.length > 1 && <div className="thumbs">{item.images.map((u, i) => <img key={u} src={u} alt="" className={i === img ? 'on' : ''} onClick={() => setImg(i)} />)}</div>}
      </div>
      <div>
        <span className="chip static">{item.category}</span>
        <h1>{item.title}</h1>
        <div className="bigprice">{inr(item.price)} <span className="tag0">0% fee</span></div>
        {item.suggestedPrice && <p className="muted small">Fair-price estimate: about {inr(item.suggestedPrice)}</p>}
        <p className="meta small muted">Condition: {CONDITIONS[item.condition]} · {item.city || 'City not set'} · {available ? 'Available' : item.status === 'reserved' ? 'Reserved' : 'Sold'}</p>
        {item.description && <p className="desc">{item.description}</p>}
        <ErrorMsg>{err}</ErrorMsg>
        {mine ? (
          <div className="row"><Link to="/orders" className="btn btn-ghost">View orders</Link><button className="btn btn-danger" onClick={remove}>Delete listing</button></div>
        ) : (
          <div className="row">
            <button className="btn" disabled={!available} onClick={order}>{available ? `Order for ${inr(item.price)}` : 'Not available'}</button>
            <button className="btn btn-ghost" onClick={chat}>Chat with seller</button>
          </div>
        )}
        <div className="card pad seller">
          <div className="row between">
            <div><Link to={`/user/${item.seller._id}`} className="textlink"><b>{item.seller.name}</b></Link><div className="small muted">{[item.seller.college, item.seller.city].filter(Boolean).join(' · ')}</div></div>
            <TrustBadge user={item.seller} full />
          </div>
          <p className="small muted">Meet and hand over in person. Phone numbers stay private: use in-app chat. Only confirm the hand-off once you have the item.</p>
        </div>
      </div>
    </div>
  );
}
