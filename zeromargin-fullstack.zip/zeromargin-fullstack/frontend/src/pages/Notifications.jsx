import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { useAuth } from '../auth.jsx';
import { Loading } from '../components/Status.jsx';

export default function Notifications() {
  const { setUnread } = useAuth();
  const [items, setItems] = useState(null);
  useEffect(() => {
    api('/notifications').then((d) => { setItems(d.items); if (d.unread) api('/notifications/read-all', { method: 'POST' }).then(() => setUnread(0)); });
  }, [setUnread]);
  if (!items) return <Loading />;
  return (
    <div className="wrap narrow section">
      <h1>Alerts</h1>
      {items.length === 0 && <div className="empty">Nothing yet. Post a <Link className="textlink" to="/wanted">Wanted Item</Link> to get match alerts.</div>}
      <div className="list">
        {items.map((n) => (
          <Link key={n._id} to={n.link || '#'} className={n.read ? 'card pad nitem' : 'card pad nitem unread'}>
            {n.text}<span className="small muted">{new Date(n.createdAt).toLocaleString()}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
