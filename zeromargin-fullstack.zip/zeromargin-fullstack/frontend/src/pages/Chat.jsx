import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api, inr } from '../api';
import { useAuth } from '../auth.jsx';
import { ErrorMsg } from '../components/Status.jsx';

export default function Chat() {
  const { id } = useParams();
  const { user, socket } = useAuth();
  const nav = useNavigate();
  const [convos, setConvos] = useState([]);
  const [active, setActive] = useState(null);
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const [err, setErr] = useState('');
  const msgBox = useRef();

  const loadList = () => api('/chat/conversations').then(setConvos).catch((e) => setErr(e.message));
  useEffect(() => { loadList(); }, [id]);

  useEffect(() => {
    if (!socket) return;
    const ping = () => loadList();
    socket.on('chat:ping', ping);
    return () => socket.off('chat:ping', ping);
  }, [socket]);

  useEffect(() => {
    if (!id) { setActive(null); setMsgs([]); return; }
    let live = true;
    api(`/chat/conversations/${id}/messages`).then((d) => { if (live) { setActive(d.conversation); setMsgs(d.messages); } }).catch((e) => setErr(e.message));
    return () => { live = false; };
  }, [id]);

  useEffect(() => {
    if (!socket || !id) return;
    const join = () => socket.emit('chat:join', id);
    join();
    socket.on('connect', join);
    const onMsg = (m) => { if (String(m.conversation) === id) setMsgs((x) => (x.some((y) => y._id === m._id) ? x : [...x, m])); };
    socket.on('chat:message', onMsg);
    return () => { socket.off('chat:message', onMsg); socket.off('connect', join); };
  }, [socket, id]);

  useEffect(() => { const el = msgBox.current; if (el) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' }); }, [msgs]);

  const send = (e) => {
    e.preventDefault();
    const t = text.trim();
    if (!t) return;
    setText('');
    socket.emit('chat:send', { conversationId: id, text: t }, (r) => { if (!r?.ok) setErr(r?.message || 'Message failed'); });
  };

  const peer = (c) => (String(c.buyer._id) === String(user._id) ? c.seller : c.buyer);

  return (
    <div className="wrap section chat">
      <aside className={id ? 'clist hide-m' : 'clist'}>
        <h2>Chats</h2>
        {convos.length === 0 && <p className="muted small">No chats yet. Open a listing and tap “Chat with seller”.</p>}
        {convos.map((c) => (
          <Link key={c._id} to={`/chat/${c._id}`} className={c._id === id ? 'citem on' : 'citem'}>
            <b>{peer(c).name}</b><span className="small muted">{c.listing?.title}</span><span className="small muted ell">{c.lastMessage}</span>
          </Link>
        ))}
      </aside>
      <section className={id ? 'cpane' : 'cpane hide-m'}>
        {!id ? <div className="empty">Select a chat</div> : (
          <>
            <div className="chead">
              <button className="linkbtn show-m" onClick={() => nav('/chat')}>← Back</button>
              {active && <div><b>{peer(active).name}</b> <span className="muted small">about <Link className="textlink" to={`/listing/${active.listing._id}`}>{active.listing.title}</Link> ({inr(active.listing.price)})</span></div>}
            </div>
            <ErrorMsg>{err}</ErrorMsg>
            <div className="msgs" ref={msgBox}>
              {msgs.map((m) => <div key={m._id} className={String(m.sender) === String(user._id) ? 'msg me' : 'msg'}>{m.text}<span>{new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></div>)}
            </div>
            <form className="csend" onSubmit={send}>
              <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message… (don't share your phone number)" maxLength={1000} />
              <button className="btn btn-sm">Send</button>
            </form>
          </>
        )}
      </section>
    </div>
  );
}
