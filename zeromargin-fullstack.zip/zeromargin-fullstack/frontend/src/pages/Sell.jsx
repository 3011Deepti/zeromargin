import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, uploadImage, CATEGORIES, CONDITIONS, inr } from '../api';
import { ErrorMsg } from '../components/Status.jsx';

export default function Sell() {
  const nav = useNavigate();
  const [f, setF] = useState({ title: '', description: '', price: '', originalPrice: '', condition: 'good', category: '', city: '' });
  const [images, setImages] = useState([]);
  const [url, setUrl] = useState('');
  const [auto, setAuto] = useState(null);
  const [sug, setSug] = useState(null);
  const [uploads, setUploads] = useState(false);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const timer = useRef();

  useEffect(() => { api('/upload/status').then((d) => setUploads(d.enabled)).catch(() => {}); }, []);

  // auto-tag category + fair price suggestion while typing
  useEffect(() => {
    clearTimeout(timer.current);
    if (f.title.trim().length < 3) { setAuto(null); setSug(null); return; }
    timer.current = setTimeout(async () => {
      try {
        const a = await api('/listings/categorize', { method: 'POST', body: { title: f.title, description: f.description } });
        setAuto(a);
        const s = await api('/listings/suggest-price', { method: 'POST', body: { title: f.title, category: f.category || a.category, condition: f.condition, originalPrice: f.originalPrice } });
        setSug(s.suggested ? s : null);
      } catch { /* suggestions are optional */ }
    }, 500);
    return () => clearTimeout(timer.current);
  }, [f.title, f.description, f.condition, f.originalPrice, f.category]);

  const addFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try { const u = await uploadImage(file); setImages((x) => [...x, u].slice(0, 5)); } catch (e2) { setErr(e2.message); }
    e.target.value = '';
  };
  const addUrl = () => { if (/^https?:\/\//.test(url)) { setImages((x) => [...x, url].slice(0, 5)); setUrl(''); } else setErr('Enter a valid image URL starting with http(s)://'); };

  const submit = async (e) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try {
      const l = await api('/listings', { method: 'POST', body: { ...f, category: f.category || undefined, images } });
      nav(`/listing/${l._id}`);
    } catch (e2) { setErr(e2.message); setBusy(false); }
  };

  return (
    <div className="wrap narrow section">
      <h1>List an item</h1>
      <p className="muted">Keep 100% of the sale. No listing fee, no commission.</p>
      <form className="form" onSubmit={submit}>
        <ErrorMsg>{err}</ErrorMsg>
        <label>Title<input required maxLength={120} value={f.title} onChange={set('title')} placeholder="e.g. Philips electric kettle 1.5L" /></label>
        <label>Description<textarea rows={3} value={f.description} onChange={set('description')} /></label>
        <div className="two">
          <label>Category {auto && !f.category && <span className="small tag0">auto: {auto.category}</span>}
            <select value={f.category} onChange={set('category')}><option value="">Auto-detect</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
          </label>
          <label>Condition<select value={f.condition} onChange={set('condition')}>{Object.entries(CONDITIONS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
        </div>
        <div className="two">
          <label>Original price when new (₹, optional)<input type="number" min="0" value={f.originalPrice} onChange={set('originalPrice')} /></label>
          <label>Your price (₹)<input type="number" min="0" required value={f.price} onChange={set('price')} /></label>
        </div>
        {sug && (
          <div className="suggest">
            <b>Fair-price suggestion: {inr(sug.suggested)}</b> <span className="muted small">(range {inr(sug.low)} – {inr(sug.high)}{sug.basedOn ? `, ${sug.basedOn} similar listings` : ''})</span>
            <button type="button" className="linkbtn" onClick={() => setF({ ...f, price: String(sug.suggested) })}>Use this</button>
          </div>
        )}
        <label>City<input value={f.city} onChange={set('city')} placeholder="Defaults to your profile city" /></label>

        <div>
          <span className="lbl">Photos (up to 5)</span>
          <div className="thumbs">{images.map((u) => <div key={u} className="rm"><img src={u} alt="" /><button type="button" onClick={() => setImages(images.filter((x) => x !== u))}>×</button></div>)}</div>
          {uploads && <input type="file" accept="image/*" onChange={addFile} />}
          <div className="row"><input placeholder="Or paste an image URL" value={url} onChange={(e) => setUrl(e.target.value)} /><button type="button" className="btn btn-ghost btn-sm" onClick={addUrl}>Add</button></div>
        </div>
        <button className="btn" disabled={busy}>{busy ? 'Publishing…' : 'Publish listing'}</button>
      </form>
    </div>
  );
}
