import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { api } from '../api';
import { useAuth } from '../auth.jsx';
import { ErrorMsg } from '../components/Status.jsx';

function useSubmit(path, fields) {
  const { login } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setErr(''); setBusy(true);
    try { login(await api(path, { method: 'POST', body: fields })); nav(loc.state?.from || '/browse'); }
    catch (e2) { setErr(e2.message); }
    finally { setBusy(false); }
  };
  return { submit, err, busy };
}

export function Login() {
  const [f, setF] = useState({ email: '', password: '' });
  const { submit, err, busy } = useSubmit('/auth/login', f);
  return (
    <div className="wrap narrow section">
      <h1>Welcome back</h1>
      <form className="form" onSubmit={submit}>
        <ErrorMsg>{err}</ErrorMsg>
        <label>Email<input type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></label>
        <label>Password<input type="password" required value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></label>
        <button className="btn" disabled={busy}>{busy ? 'Logging in…' : 'Log in'}</button>
        <p className="muted small">New here? <Link to="/register" className="textlink">Create an account</Link></p>
      </form>
    </div>
  );
}

export function Register() {
  const [f, setF] = useState({ name: '', email: '', password: '', college: '', city: '' });
  const { submit, err, busy } = useSubmit('/auth/register', f);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <div className="wrap narrow section">
      <h1>Join ZeroMargin</h1>
      <form className="form" onSubmit={submit}>
        <ErrorMsg>{err}</ErrorMsg>
        <label>Full name<input required value={f.name} onChange={set('name')} /></label>
        <label>Email<input type="email" required value={f.email} onChange={set('email')} /></label>
        <label>Password (6+ characters)<input type="password" minLength={6} required value={f.password} onChange={set('password')} /></label>
        <div className="two">
          <label>College (optional)<input value={f.college} onChange={set('college')} /></label>
          <label>City<input value={f.city} onChange={set('city')} /></label>
        </div>
        <button className="btn" disabled={busy}>{busy ? 'Creating…' : 'Create account'}</button>
        <p className="muted small">Already a member? <Link to="/login" className="textlink">Log in</Link></p>
      </form>
    </div>
  );
}
