export default function Footer() {
  return (
    <footer className="foot">
      <div className="wrap">
        <strong>ZeroMargin</strong> · The value stays with the people who made the trade.
        <div className="muted small">Built by Team Binary Brains · IGDTUW</div>
      </div>
    </footer>
  );
}
