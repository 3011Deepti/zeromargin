import { Link } from 'react-router-dom';
import { inr, CONDITIONS } from '../api';
import TrustBadge from './TrustBadge.jsx';

export default function ListingCard({ item }) {
  return (
    <Link to={`/listing/${item._id}`} className="card lcard">
      <div className="thumb">
        {item.images?.[0] ? <img src={item.images[0]} alt={item.title} loading="lazy" /> : <span className="thumb-ph">{item.category?.[0] || '·'}</span>}
        <span className="chip">{item.category}</span>
      </div>
      <div className="lbody">
        <h3>{item.title}</h3>
        <div className="price">{inr(item.price)} <span className="muted small">· {CONDITIONS[item.condition]}</span></div>
        <div className="row small">
          <span className="muted">{item.seller?.name}</span>
          <TrustBadge user={item.seller} />
        </div>
      </div>
    </Link>
  );
}
