import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { useAuth } from '../auth.jsx';

export default function Navbar() {
  const { user, logout, unread } = useAuth();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);

  return (
    <header className="nav">
      <div className="wrap nav-in">
        <Link to="/" className="logo" onClick={close}><span className="logo-zero">0</span>ZeroMargin</Link>
        <button className="burger" aria-label="Menu" onClick={() => setOpen(!open)}>☰</button>
        <nav className={open ? 'links open' : 'links'} onClick={close}>
          <NavLink to="/browse">Browse</NavLink>
          <NavLink to="/wanted">Wanted</NavLink>
          {user ? (
            <>
              <NavLink to="/orders">Orders</NavLink>
              <NavLink to="/chat">Chat</NavLink>
              <NavLink to="/notifications">Alerts{unread > 0 && <span className="dot">{unread}</span>}</NavLink>
              <Link to="/sell" className="btn btn-sm">+ Sell</Link>
              <button className="linkbtn" onClick={() => { logout(); nav('/'); }}>Log out ({user.name.split(' ')[0]})</button>
            </>
          ) : (
            <>
              <NavLink to="/login">Log in</NavLink>
              <Link to="/register" className="btn btn-sm">Join free</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
