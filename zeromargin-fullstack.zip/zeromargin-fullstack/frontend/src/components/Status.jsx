export const Loading = () => <div className="center muted">Loading…</div>;
export const ErrorMsg = ({ children }) => (children ? <div className="alert">{children}</div> : null);
