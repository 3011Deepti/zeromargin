import { trustOf } from '../api';

export default function TrustBadge({ user, full }) {
  const t = trustOf(user);
  const total = (user?.verifiedTrades || 0) + (user?.disputedTrades || 0);
  if (t === null) return <span className="badge badge-new">New member</span>;
  const cls = t >= 80 ? 'badge-hi' : t >= 50 ? 'badge-mid' : 'badge-lo';
  return <span className={`badge ${cls}`} title={`${user.verifiedTrades} verified of ${total} completed`}>✔ {t}% trust{full ? ` · ${user.verifiedTrades}/${total} verified` : ''}</span>;
}
