// Drop-in replacement for socket.io-client that talks to standalone/server.js over
// Server-Sent Events (server -> browser) and plain fetch (browser -> server).
// It implements only what the ZeroMargin frontend uses: on / off / emit / disconnect.
export function io(url, opts = {}) {
  const token = opts.auth && opts.auth.token;
  const handlers = {};
  const fire = (ev, ...args) => (handlers[ev] || []).slice().forEach((f) => f(...args));
  const es = new EventSource(`${url}/api/stream?token=${encodeURIComponent(token || '')}`);
  es.onopen = () => fire('connect');
  ['notification', 'chat:message', 'chat:ping'].forEach((ev) =>
    es.addEventListener(ev, (e) => { try { fire(ev, JSON.parse(e.data)); } catch { /* ignore bad frame */ } })
  );
  return {
    on(ev, f) { (handlers[ev] = handlers[ev] || []).push(f); },
    off(ev, f) { handlers[ev] = (handlers[ev] || []).filter((x) => x !== f); },
    emit(ev, payload, ack) {
      if (ev !== 'chat:send') return; // chat:join is not needed: the server pushes to both participants
      fetch(`${url}/api/chat/conversations/${payload.conversationId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ text: payload.text }),
      })
        .then(async (r) => (r.ok ? ack && ack({ ok: true }) : ack && ack({ ok: false, message: (await r.json().catch(() => ({}))).message })))
        .catch(() => ack && ack({ ok: false, message: 'Network error' }));
    },
    disconnect() { es.close(); },
  };
}
