// Minimal stand-in for react-router-dom (v6 API subset used by ZeroMargin) for offline demo builds.
import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';

const Loc = createContext(null);
const Params = createContext({});

export function BrowserRouter({ children }) {
  const [loc, setLoc] = useState({ pathname: location.pathname, search: location.search, state: history.state?.usr ?? null });
  useEffect(() => {
    const on = () => setLoc({ pathname: location.pathname, search: location.search, state: history.state?.usr ?? null });
    window.addEventListener('popstate', on);
    return () => window.removeEventListener('popstate', on);
  }, []);
  const navigate = useCallback((to, opts = {}) => {
    if (typeof to === 'number') return history.go(to);
    history[opts.replace ? 'replaceState' : 'pushState']({ usr: opts.state ?? null }, '', to);
    const u = new URL(to, location.href);
    setLoc({ pathname: u.pathname, search: u.search, state: opts.state ?? null });
  }, []);
  return <Loc.Provider value={{ loc, navigate }}>{children}</Loc.Provider>;
}

export const useLocation = () => useContext(Loc).loc;
export const useNavigate = () => useContext(Loc).navigate;
export const useParams = () => useContext(Params);

export function useSearchParams() {
  const { loc, navigate } = useContext(Loc);
  const sp = useMemo(() => new URLSearchParams(loc.search), [loc.search]);
  const set = (n) => navigate(loc.pathname + (n.toString() ? '?' + n.toString() : ''));
  return [sp, set];
}

function match(pattern, path) {
  if (pattern === '*') return {};
  const a = pattern.split('/').filter(Boolean), b = path.split('/').filter(Boolean);
  if (a.length !== b.length) return null;
  const params = {};
  for (let i = 0; i < a.length; i++) {
    if (a[i].startsWith(':')) params[a[i].slice(1)] = decodeURIComponent(b[i]);
    else if (a[i] !== b[i]) return null;
  }
  return params;
}

export const Route = () => null;
export function Routes({ children }) {
  const { pathname } = useLocation();
  const routes = React.Children.toArray(children);
  let star = null;
  for (const r of routes) {
    if (r.props.path === '*') { star = r; continue; }
    const p = match(r.props.path, pathname);
    if (p) return <Params.Provider value={p}>{r.props.element}</Params.Provider>;
  }
  return star ? star.props.element : null;
}

export function Navigate({ to, replace, state }) {
  const navigate = useNavigate();
  useEffect(() => { navigate(to, { replace, state }); }, []);
  return null;
}

export function Link({ to, children, onClick, ...rest }) {
  const navigate = useNavigate();
  return (
    <a href={to} {...rest} onClick={(e) => {
      onClick?.(e);
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey) return;
      e.preventDefault(); navigate(to);
    }}>{children}</a>
  );
}

export function NavLink({ to, className, ...rest }) {
  const { pathname } = useLocation();
  const active = pathname === to || pathname.startsWith(to + '/');
  const cls = typeof className === 'function' ? className({ isActive: active }) : [className, active && 'active'].filter(Boolean).join(' ');
  return <Link to={to} className={cls || undefined} {...rest} />;
}
