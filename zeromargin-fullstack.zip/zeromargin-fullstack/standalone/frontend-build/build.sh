#!/bin/bash
# Rebuilds standalone/public from ../frontend/src (only needed if you change the React code).
# Needs Bun (https://bun.sh). It bundles the real frontend source, swapping in the two small shims in this folder.
set -e
cd "$(dirname "$0")"
W=$(mktemp -d)
cp -r ../../frontend/src "$W/src"; mkdir -p "$W/shims" "$W/node_modules"
cp router.jsx "$W/shims/router.jsx"; cp socket.js "$W/shims/socket.js"
cat > "$W/tsconfig.json" <<'JSON'
{"compilerOptions":{"jsx":"react-jsx","baseUrl":".","paths":{"react-router-dom":["shims/router.jsx"],"socket.io-client":["shims/socket.js"]}}}
JSON
( cd "$W" && npm init -y >/dev/null && npm install react react-dom --silent )
( cd "$W" && bun build src/main.jsx --outdir out --production --define 'import.meta.env={"VITE_API_URL":"__ZM_API__"}' )
sed -i 's/"__ZM_API__"/location.origin/g' "$W/out/main.js"
cp "$W/out/main.js" "$W/out/main.css" ../public/
echo "Rebuilt standalone/public"
