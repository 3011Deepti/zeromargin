import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import authRoutes from './routes/auth.js';
import userRoutes from './routes/users.js';
import listingRoutes from './routes/listings.js';
import orderRoutes from './routes/orders.js';
import chatRoutes from './routes/chat.js';
import wantedRoutes from './routes/wanted.js';
import notificationRoutes from './routes/notifications.js';
import uploadRoutes from './routes/upload.js';

export const allowedOrigins = () => (process.env.CLIENT_URL || 'http://localhost:5173').split(',').map((s) => s.trim().replace(/\/$/, ''));

const app = express();
app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: (origin, cb) => (!origin || allowedOrigins().includes(origin) ? cb(null, true) : cb(new Error('Not allowed by CORS'))) }));
app.use(express.json({ limit: '100kb' }));

app.get('/', (req, res) => res.json({ name: 'ZeroMargin API', status: 'ok' }));
app.get('/api/health', (req, res) => res.json({ status: 'ok' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, max: 100, standardHeaders: true, legacyHeaders: false }), authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/listings', listingRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/wanted', wantedRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/upload', uploadRoutes);

app.use((req, res) => res.status(404).json({ message: 'Not found' }));
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  console.error(err);
  res.status(err.status || 500).json({ message: err.status ? err.message : 'Something went wrong' });
});

export default app;
