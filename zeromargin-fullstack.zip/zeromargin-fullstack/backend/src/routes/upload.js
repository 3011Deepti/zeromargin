import { Router } from 'express';
import multer from 'multer';
import { v2 as cloudinary } from 'cloudinary';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
const configured = () => process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET;

router.get('/status', (req, res) => res.json({ enabled: !!configured() }));

router.post('/', requireAuth, upload.single('image'), (req, res) => {
  if (!configured()) return res.status(503).json({ message: 'Image uploads are not configured. Paste an image URL instead.' });
  if (!req.file || !req.file.mimetype.startsWith('image/')) return res.status(400).json({ message: 'Please upload an image file' });
  cloudinary.config({ cloud_name: process.env.CLOUDINARY_CLOUD_NAME, api_key: process.env.CLOUDINARY_API_KEY, api_secret: process.env.CLOUDINARY_API_SECRET });
  cloudinary.uploader
    .upload_stream({ folder: 'zeromargin', transformation: [{ width: 1200, crop: 'limit', quality: 'auto' }] }, (err, result) => {
      if (err) return res.status(502).json({ message: 'Upload failed' });
      res.json({ url: result.secure_url });
    })
    .end(req.file.buffer);
});

export default router;
