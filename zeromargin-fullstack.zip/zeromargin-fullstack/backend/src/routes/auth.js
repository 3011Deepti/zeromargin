import { Router } from 'express';
import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import { signToken, requireAuth } from '../middleware/auth.js';

const router = Router();
const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

router.post('/register', async (req, res) => {
  const { name, email, password, college = '', city = '' } = req.body || {};
  if (!name || !emailRe.test(email || '') || (password || '').length < 6)
    return res.status(400).json({ message: 'Name, a valid email and a password of 6+ characters are required' });
  if (await User.findOne({ email: email.toLowerCase() })) return res.status(409).json({ message: 'Email already registered' });
  const user = await User.create({ name, email, college, city, password: await bcrypt.hash(password, 10) });
  res.status(201).json({ token: signToken(user._id), user });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  const user = await User.findOne({ email: (email || '').toLowerCase() }).select('+password');
  if (!user || !(await bcrypt.compare(password || '', user.password))) return res.status(401).json({ message: 'Invalid email or password' });
  res.json({ token: signToken(user._id), user });
});

router.get('/me', requireAuth, (req, res) => res.json({ user: req.user }));

export default router;
