import { Router } from 'express';
import Conversation from '../models/Conversation.js';
import Message from '../models/Message.js';
import Listing from '../models/Listing.js';
import { requireAuth } from '../middleware/auth.js';
import { saveMessage } from '../services/chat.js';

const router = Router();
router.use(requireAuth);

// Start (or reopen) a chat with a seller about a listing
router.post('/conversations', async (req, res) => {
  const listing = await Listing.findById(req.body?.listingId);
  if (!listing) return res.status(404).json({ message: 'Listing not found' });
  if (String(listing.seller) === String(req.user._id)) return res.status(400).json({ message: "That's your own listing" });
  const convo = await Conversation.findOneAndUpdate(
    { listing: listing._id, buyer: req.user._id },
    { $setOnInsert: { listing: listing._id, buyer: req.user._id, seller: listing.seller } },
    { upsert: true, new: true }
  );
  res.json(convo);
});

router.get('/conversations', async (req, res) => {
  const list = await Conversation.find({ $or: [{ buyer: req.user._id }, { seller: req.user._id }] })
    .sort('-updatedAt').populate('listing', 'title images').populate('buyer', 'name').populate('seller', 'name');
  res.json(list);
});

router.get('/conversations/:id/messages', async (req, res) => {
  const convo = await Conversation.findById(req.params.id).populate('listing', 'title price images').populate('buyer', 'name').populate('seller', 'name');
  const uid = String(req.user._id);
  if (!convo || (uid !== String(convo.buyer._id) && uid !== String(convo.seller._id))) return res.status(404).json({ message: 'Conversation not found' });
  const messages = await Message.find({ conversation: convo._id }).sort('createdAt').limit(300);
  res.json({ conversation: convo, messages });
});

router.post('/conversations/:id/messages', async (req, res) => {
  try {
    res.status(201).json(await saveMessage(req.params.id, req.user._id, req.body?.text));
  } catch (e) {
    res.status(400).json({ message: e.message });
  }
});

export default router;
