import { Router } from 'express';
import mongoose from 'mongoose';
import Listing, { CATEGORIES, CONDITIONS } from '../models/Listing.js';
import { requireAuth } from '../middleware/auth.js';
import { categorize } from '../utils/categorize.js';
import { suggestPrice } from '../utils/pricing.js';
import { matchListingToWanted } from '../services/matching.js';

const router = Router();
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

router.get('/', async (req, res) => {
  const { q, category, condition, minPrice, maxPrice, sort = 'new', page = 1, limit = 12, city } = req.query;
  const filter = { status: 'available' };
  if (q) filter.$or = [{ title: new RegExp(esc(q), 'i') }, { description: new RegExp(esc(q), 'i') }, { tags: new RegExp(esc(q), 'i') }];
  if (CATEGORIES.includes(category)) filter.category = category;
  if (CONDITIONS.includes(condition)) filter.condition = condition;
  if (city) filter.city = new RegExp(`^${esc(city)}$`, 'i');
  if (minPrice || maxPrice) {
    filter.price = {};
    if (minPrice) filter.price.$gte = Number(minPrice);
    if (maxPrice) filter.price.$lte = Number(maxPrice);
  }
  const sortBy = { new: '-createdAt', low: 'price', high: '-price' }[sort] || '-createdAt';
  const p = Math.max(1, Number(page));
  const l = Math.min(48, Math.max(1, Number(limit)));
  const [items, total] = await Promise.all([
    Listing.find(filter).sort(sortBy).skip((p - 1) * l).limit(l).populate('seller', 'name verifiedTrades disputedTrades'),
    Listing.countDocuments(filter),
  ]);
  res.json({ items, total, page: p, pages: Math.ceil(total / l) });
});

router.get('/mine', requireAuth, async (req, res) => {
  res.json(await Listing.find({ seller: req.user._id }).sort('-createdAt'));
});

router.post('/categorize', (req, res) => res.json(categorize(req.body?.title, req.body?.description)));

router.post('/suggest-price', async (req, res) => {
  const { title, category, condition, originalPrice } = req.body || {};
  res.json(await suggestPrice({ title, category, condition, originalPrice: Number(originalPrice) || 0 }));
});

router.get('/:id', async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: 'Listing not found' });
  const item = await Listing.findById(req.params.id).populate('seller', 'name college city verifiedTrades disputedTrades createdAt');
  if (!item) return res.status(404).json({ message: 'Listing not found' });
  res.json(item);
});

router.post('/', requireAuth, async (req, res) => {
  const { title, description = '', price, originalPrice, condition = 'good', images = [], city } = req.body || {};
  if (!title || !(Number(price) >= 0) || price === '' || price == null) return res.status(400).json({ message: 'Title and price are required' });
  const auto = categorize(title, description);
  const category = CATEGORIES.includes(req.body.category) ? req.body.category : auto.category;
  const sp = await suggestPrice({ title, category, condition, originalPrice: Number(originalPrice) || 0 });
  const listing = await Listing.create({
    seller: req.user._id, title, description, price: Number(price), originalPrice: Number(originalPrice) || undefined,
    suggestedPrice: sp.suggested || undefined, category, tags: auto.tags,
    condition: CONDITIONS.includes(condition) ? condition : 'good',
    images: (Array.isArray(images) ? images : []).filter((u) => /^https?:\/\//.test(u)).slice(0, 5),
    city: city || req.user.city,
  });
  matchListingToWanted(listing).catch((e) => console.error('match error', e.message));
  res.status(201).json(listing);
});

router.put('/:id', requireAuth, async (req, res) => {
  const item = await Listing.findOne({ _id: req.params.id, seller: req.user._id });
  if (!item) return res.status(404).json({ message: 'Listing not found' });
  for (const k of ['title', 'description', 'price', 'condition', 'city']) if (req.body[k] !== undefined) item[k] = req.body[k];
  if (CATEGORIES.includes(req.body.category)) item.category = req.body.category;
  await item.save();
  res.json(item);
});

router.delete('/:id', requireAuth, async (req, res) => {
  const item = await Listing.findOneAndDelete({ _id: req.params.id, seller: req.user._id });
  if (!item) return res.status(404).json({ message: 'Listing not found' });
  res.json({ ok: true });
});

export default router;
