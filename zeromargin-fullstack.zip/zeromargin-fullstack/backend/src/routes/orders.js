import { Router } from 'express';
import Order from '../models/Order.js';
import Listing from '../models/Listing.js';
import User from '../models/User.js';
import { requireAuth } from '../middleware/auth.js';
import { notify } from '../services/notify.js';

const router = Router();
router.use(requireAuth);

const populate = (q) => q.populate('listing', 'title images price status').populate('buyer', 'name verifiedTrades disputedTrades').populate('seller', 'name verifiedTrades disputedTrades');

router.post('/', async (req, res) => {
  const listing = await Listing.findById(req.body?.listingId);
  if (!listing || listing.status !== 'available') return res.status(400).json({ message: 'This item is no longer available' });
  if (String(listing.seller) === String(req.user._id)) return res.status(400).json({ message: "You can't order your own listing" });
  const dup = await Order.findOne({ listing: listing._id, buyer: req.user._id, status: { $in: ['placed', 'accepted', 'handed_off'] } });
  if (dup) return res.status(409).json({ message: 'You already have an open order for this item' });
  const order = await Order.create({ listing: listing._id, buyer: req.user._id, seller: listing.seller, price: listing.price });
  await notify(listing.seller, `${req.user.name} placed an order for "${listing.title}"`, '/orders');
  res.status(201).json(order);
});

router.get('/mine', async (req, res) => {
  const orders = await populate(Order.find({ $or: [{ buyer: req.user._id }, { seller: req.user._id }] }).sort('-createdAt'));
  res.json(orders);
});

const load = async (req, res, role) => {
  const order = await Order.findById(req.params.id);
  if (!order || String(order[role]) !== String(req.user._id)) {
    res.status(404).json({ message: 'Order not found' });
    return null;
  }
  return order;
};
const guard = (res, order, from) => {
  if (!from.includes(order.status)) {
    res.status(400).json({ message: `Order is already ${order.status.replace('_', ' ')}` });
    return false;
  }
  return true;
};

// Seller accepts -> item reserved
router.patch('/:id/accept', async (req, res) => {
  const order = await load(req, res, 'seller');
  if (!order || !guard(res, order, ['placed'])) return;
  const listing = await Listing.findById(order.listing);
  if (!listing || listing.status !== 'available') return res.status(400).json({ message: 'Item is no longer available' });
  listing.status = 'reserved';
  await listing.save();
  order.status = 'accepted';
  await order.save();
  // other open orders for the same item are declined
  const others = await Order.find({ listing: order.listing, _id: { $ne: order._id }, status: 'placed' });
  for (const o of others) {
    o.status = 'cancelled';
    await o.save();
    await notify(o.buyer, `"${listing.title}" was reserved for another buyer`, '/orders');
  }
  await notify(order.buyer, `${req.user.name} accepted your order for "${listing.title}". Use chat to arrange the hand-off.`, '/orders');
  res.json(order);
});

// Seller declines, or either side cancels before hand-off
router.patch('/:id/cancel', async (req, res) => {
  const order = await Order.findById(req.params.id);
  const uid = String(req.user._id);
  if (!order || (uid !== String(order.buyer) && uid !== String(order.seller))) return res.status(404).json({ message: 'Order not found' });
  if (!guard(res, order, ['placed', 'accepted'])) return;
  if (order.status === 'accepted') await Listing.findByIdAndUpdate(order.listing, { status: 'available' });
  order.status = 'cancelled';
  await order.save();
  await notify(uid === String(order.buyer) ? order.seller : order.buyer, `${req.user.name} cancelled an order`, '/orders');
  res.json(order);
});

// Seller says "I handed it over"
router.patch('/:id/handoff', async (req, res) => {
  const order = await load(req, res, 'seller');
  if (!order || !guard(res, order, ['accepted'])) return;
  order.status = 'handed_off';
  await order.save();
  await notify(order.buyer, `${req.user.name} marked the hand-off done. Please confirm you received the item.`, '/orders');
  res.json(order);
});

// Buyer verifies the hand-off. Verified? yes -> trust score goes up. no -> disputed, counts against seller.
router.patch('/:id/verify', async (req, res) => {
  const order = await load(req, res, 'buyer');
  if (!order || !guard(res, order, ['handed_off'])) return;
  const verified = req.body?.verified === true;
  order.status = verified ? 'completed' : 'disputed';
  await order.save();
  await User.findByIdAndUpdate(order.seller, { $inc: verified ? { verifiedTrades: 1 } : { disputedTrades: 1 } });
  if (verified) await User.findByIdAndUpdate(order.buyer, { $inc: { verifiedTrades: 1 } });
  await Listing.findByIdAndUpdate(order.listing, { status: verified ? 'sold' : 'available' });
  await notify(order.seller, verified ? `Hand-off verified! Your trust score just went up.` : `A buyer reported a problem with a hand-off.`, '/orders');
  res.json(order);
});

export default router;
