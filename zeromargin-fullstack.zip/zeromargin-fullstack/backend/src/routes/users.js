import { Router } from 'express';
import mongoose from 'mongoose';
import User from '../models/User.js';
import Listing from '../models/Listing.js';

const router = Router();

router.get('/:id', async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).json({ message: 'Not found' });
  const user = await User.findById(req.params.id).select('name college city verifiedTrades disputedTrades createdAt');
  if (!user) return res.status(404).json({ message: 'Not found' });
  const listings = await Listing.find({ seller: user._id, status: { $ne: 'sold' } }).sort('-createdAt').limit(24);
  res.json({ user, listings });
});

export default router;
