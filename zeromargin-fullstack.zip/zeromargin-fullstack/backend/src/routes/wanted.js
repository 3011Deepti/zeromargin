import { Router } from 'express';
import Wanted from '../models/Wanted.js';
import { CATEGORIES } from '../models/Listing.js';
import { requireAuth } from '../middleware/auth.js';
import { categorize, keywordsOf } from '../utils/categorize.js';
import { matchWantedToListings } from '../services/matching.js';

const router = Router();

router.get('/', async (req, res) => {
  res.json(await Wanted.find({ active: true }).sort('-createdAt').limit(100).populate('user', 'name'));
});

router.get('/mine', requireAuth, async (req, res) => res.json(await Wanted.find({ user: req.user._id }).sort('-createdAt')));

router.post('/', requireAuth, async (req, res) => {
  const { title, maxPrice, category } = req.body || {};
  if (!title || !(Number(maxPrice) > 0)) return res.status(400).json({ message: 'Title and max price are required' });
  const want = await Wanted.create({
    user: req.user._id, title, maxPrice: Number(maxPrice),
    category: CATEGORIES.includes(category) ? category : categorize(title).category,
    keywords: keywordsOf(title).slice(0, 6),
  });
  matchWantedToListings(want).catch((e) => console.error('match error', e.message));
  res.status(201).json(want);
});

router.delete('/:id', requireAuth, async (req, res) => {
  const w = await Wanted.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!w) return res.status(404).json({ message: 'Not found' });
  res.json({ ok: true });
});

export default router;
