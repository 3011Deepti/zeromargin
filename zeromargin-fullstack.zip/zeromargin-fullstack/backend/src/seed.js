// Demo data: `npm run seed`
//
// Fills the database with the same demo marketplace shown in the ZeroMargin demo video:
// five members with different trust scores, eight listings, an open order that is waiting for
// the buyer to confirm, a chat, and two "Wanted" requests.
//
//   npm run seed              reset the demo data (safe to re-run; only touches *@zeromargin.demo accounts)
//   node src/seed.js --if-empty   seed only when the database has no users yet (used by Docker)
//
// Demo login (everyone shares the password):  ananya@zeromargin.demo / demo1234
import 'dotenv/config';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import User from './models/User.js';
import Listing from './models/Listing.js';
import Order from './models/Order.js';
import Conversation from './models/Conversation.js';
import Message from './models/Message.js';
import Notification from './models/Notification.js';
import Wanted from './models/Wanted.js';
import { categorize, keywordsOf } from './utils/categorize.js';

const DOMAIN = '@zeromargin.demo';
const PASSWORD = 'demo1234';
const ifEmpty = process.argv.includes('--if-empty');

if (!process.env.MONGO_URI) {
  console.error('Missing MONGO_URI. Copy .env.example to .env first.');
  process.exit(1);
}
await mongoose.connect(process.env.MONGO_URI);

if (ifEmpty && (await User.countDocuments()) > 0) {
  console.log('Database already has data - skipping demo seed.');
  await mongoose.disconnect();
  process.exit(0);
}

// ---- 1. remove any earlier demo data (and only demo data) ----
const oldUsers = (await User.find({ email: new RegExp(`${DOMAIN.replace('.', '\\.')}$`) }).select('_id')).map((u) => u._id);
if (oldUsers.length) {
  const oldListings = (await Listing.find({ seller: { $in: oldUsers } }).select('_id')).map((l) => l._id);
  const oldConvos = (await Conversation.find({ $or: [{ buyer: { $in: oldUsers } }, { seller: { $in: oldUsers } }] }).select('_id')).map((c) => c._id);
  await Message.deleteMany({ conversation: { $in: oldConvos } });
  await Conversation.deleteMany({ _id: { $in: oldConvos } });
  await Order.deleteMany({ $or: [{ buyer: { $in: oldUsers } }, { seller: { $in: oldUsers } }, { listing: { $in: oldListings } }] });
  await Wanted.deleteMany({ user: { $in: oldUsers } });
  await Notification.deleteMany({ user: { $in: oldUsers } });
  await Listing.deleteMany({ _id: { $in: oldListings } });
  await User.deleteMany({ _id: { $in: oldUsers } });
}

// Mongoose stamps createdAt/updatedAt itself, so back-date through the raw collection
const ago = (hours) => new Date(Date.now() - hours * 3600 * 1000);
const backdate = (Model, id, date) => Model.collection.updateOne({ _id: id }, { $set: { createdAt: date, updatedAt: date } });

// ---- 2. members (trust = verified / (verified + disputed)) ----
const hash = await bcrypt.hash(PASSWORD, 10);
const members = {};
for (const [key, name, college, city, verified, disputed, daysAgo] of [
  ['ananya', 'Ananya Sharma', 'IGDTUW', 'Delhi', 0, 0, 40], //  new member, no rating yet
  ['riya', 'Riya Verma', 'DTU', 'Delhi', 17, 1, 200], //        94%
  ['kabir', 'Kabir Singh', 'NSUT', 'Delhi', 14, 2, 150], //     88%
  ['meera', 'Meera Nair', 'IGDTUW', 'Delhi', 0, 0, 6], //       new member
  ['dev', 'Dev Malhotra', 'JMI', 'Noida', 8, 0, 90], //         100%
]) {
  const u = await User.create({ name, email: `${key}${DOMAIN}`, password: hash, college, city, verifiedTrades: verified, disputedTrades: disputed });
  await backdate(User, u._id, ago(daysAgo * 24));
  members[key] = u;
}

// ---- 3. listings (images are the illustrations in frontend/public/demo) ----
const listings = [
  // title, price, category, condition, picture, seller, city, description, posted N hours ago
  ['Philips electric kettle 1.5L', 650, 'Home & Kitchen', 'good', 'kettle', 'riya', 'Delhi', 'Works perfectly, auto shut-off. Bought last year, moving out of the hostel.', 3],
  ['Engineering Mathematics, Kreyszig 10th ed.', 320, 'Books', 'good', 'book', 'kabir', 'Delhi', 'Light highlighting in the first three chapters. No torn pages.', 8],
  ['Study desk with drawer', 2800, 'Furniture', 'good', 'desk', 'dev', 'Noida', 'Solid wood, 120 cm wide. Pickup only.', 20],
  ['Casio fx-991EX scientific calculator', 700, 'Electronics', 'like_new', 'calc', 'riya', 'Delhi', 'Used for one semester. Cover included.', 26],
  ['Denim jacket, size M', 900, 'Clothing', 'good', 'jacket', 'meera', 'Delhi', 'Classic fit, no fading.', 30],
  ['Yonex badminton racquet', 850, 'Sports & Fitness', 'good', 'racquet', 'kabir', 'Delhi', 'Restrung last month. Comes with a cover.', 40],
  ['Wireless over-ear headphones', 1200, 'Electronics', 'like_new', 'headphones', 'dev', 'Noida', '20 hours battery, original box and cable.', 52],
  ['Hostel mini fridge 90L', 4500, 'Home & Kitchen', 'good', 'fridge', 'riya', 'Delhi', 'Cools well, quiet compressor.', 70],
];
const made = {};
for (const [title, price, category, condition, pic, seller, city, description, hours] of listings) {
  const l = await Listing.create({
    seller: members[seller]._id, title, description, price, category, condition, city,
    tags: categorize(title, description).tags, images: [`/demo/${pic}.svg`], status: 'available',
  });
  await backdate(Listing, l._id, ago(hours));
  made[pic] = l;
}

// The calculator that Ananya already bought: reserved, so it is hidden from Browse
const bought = await Listing.create({
  seller: members.riya._id, title: 'Casio fx-991EX scientific calculator', description: 'Used for one semester. Cover included.',
  price: 700, category: 'Electronics', condition: 'like_new', city: 'Delhi', tags: ['calculator'], images: ['/demo/calc.svg'], status: 'reserved',
});
await backdate(Listing, bought._id, ago(60));

// ---- 4. an open order: Riya handed it over, Ananya still has to confirm ----
const order = await Order.create({ listing: bought._id, buyer: members.ananya._id, seller: members.riya._id, price: 700, status: 'handed_off' });
await backdate(Order, order._id, ago(24));

// ---- 5. a chat between Ananya and Riya about the kettle ----
const convo = await Conversation.create({
  listing: made.kettle._id, buyer: members.ananya._id, seller: members.riya._id,
  lastMessage: 'Yes it is! You can pick it up near the DTU main gate.',
});
for (const [sender, text, minutes] of [
  ['ananya', 'Hi! Is the kettle still available?', 60],
  ['riya', 'Yes it is! You can pick it up near the DTU main gate.', 50],
]) {
  const m = await Message.create({ conversation: convo._id, sender: members[sender]._id, text });
  await backdate(Message, m._id, ago(minutes / 60));
}
await backdate(Conversation, convo._id, ago(50 / 60));

// ---- 6. other people's "Wanted" requests ----
for (const [key, title, category, maxPrice, hours] of [
  ['kabir', 'Second-hand drafting kit', 'Other', 400, 5],
  ['meera', 'Compact study lamp', 'Home & Kitchen', 300, 2],
]) {
  const w = await Wanted.create({ user: members[key]._id, title, category, maxPrice, keywords: keywordsOf(title).slice(0, 6) });
  await backdate(Wanted, w._id, ago(hours));
}

console.log(`Seeded ${Object.keys(members).length} members, ${listings.length} listings, 1 order, 1 chat, 2 wanted items.`);
console.log(`Log in as  ananya${DOMAIN}  (password: ${PASSWORD})   - the account used in the demo video.`);
console.log(`Other members: riya, kabir, meera, dev @zeromargin.demo (same password).`);
await mongoose.disconnect();
