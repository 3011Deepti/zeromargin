import Wanted from '../models/Wanted.js';
import Listing from '../models/Listing.js';
import { notify } from './notify.js';
import { keywordsOf } from '../utils/categorize.js';

const hit = (kws, text) => !kws.length || kws.some((k) => text.includes(k));

// A new listing was posted -> alert buyers with a matching "Wanted Item"
export async function matchListingToWanted(listing) {
  const wants = await Wanted.find({
    active: true,
    category: listing.category,
    maxPrice: { $gte: listing.price },
    user: { $ne: listing.seller },
  });
  const text = `${listing.title} ${listing.description}`.toLowerCase();
  for (const w of wants) {
    const kws = w.keywords?.length ? w.keywords : keywordsOf(w.title);
    if (hit(kws, text)) await notify(w.user, `Match for your wanted item "${w.title}": ${listing.title} at ₹${listing.price}`, `/listing/${listing._id}`);
  }
}

// A new wanted item was posted -> alert sellers whose existing listings match
export async function matchWantedToListings(want) {
  const kws = want.keywords?.length ? want.keywords : keywordsOf(want.title);
  const listings = await Listing.find({ status: 'available', category: want.category, price: { $lte: want.maxPrice }, seller: { $ne: want.user } }).limit(100);
  const sellers = new Set();
  const matches = [];
  for (const l of listings) {
    if (!hit(kws, `${l.title} ${l.description}`.toLowerCase())) continue;
    matches.push(l);
    if (sellers.has(String(l.seller))) continue;
    sellers.add(String(l.seller));
    await notify(l.seller, `A buyer is looking for "${want.title}" (up to ₹${want.maxPrice}) - your listing "${l.title}" matches`, '/wanted');
  }
  // ...and tell the buyer right away if something that already exists fits their budget
  for (const l of matches.slice(0, 3)) {
    await notify(want.user, `Match found: “${l.title}” was listed at ₹${l.price}, within your ₹${want.maxPrice} budget.`, `/listing/${l._id}`);
  }
}
