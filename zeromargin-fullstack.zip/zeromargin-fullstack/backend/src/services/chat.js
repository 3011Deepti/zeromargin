import Conversation from '../models/Conversation.js';
import Message from '../models/Message.js';
import { getIO, notify } from './notify.js';

export async function saveMessage(conversationId, userId, text) {
  const convo = await Conversation.findById(conversationId);
  if (!convo) throw new Error('Conversation not found');
  const uid = String(userId);
  if (uid !== String(convo.buyer) && uid !== String(convo.seller)) throw new Error('Not allowed');
  const clean = String(text || '').trim().slice(0, 1000);
  if (!clean) throw new Error('Empty message');
  const msg = await Message.create({ conversation: convo._id, sender: userId, text: clean });
  convo.lastMessage = clean;
  await convo.save();
  const other = uid === String(convo.buyer) ? convo.seller : convo.buyer;
  getIO()?.to(`conv:${convo._id}`).emit('chat:message', msg);
  getIO()?.to(`user:${other}`).emit('chat:ping', { conversation: String(convo._id) });
  return msg;
}
export { notify };
