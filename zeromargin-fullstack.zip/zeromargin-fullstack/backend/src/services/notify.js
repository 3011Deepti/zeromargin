import Notification from '../models/Notification.js';

let io = null;
export const setIO = (instance) => (io = instance);
export const getIO = () => io;

export async function notify(userId, text, link = '') {
  const n = await Notification.create({ user: userId, text, link });
  io?.to(`user:${userId}`).emit('notification', n);
  return n;
}
