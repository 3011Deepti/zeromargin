import Listing from '../models/Listing.js';
import { keywordsOf } from './categorize.js';

// Slide 4: "Fair-pricing engine". Estimates a fair resale price from
//  (a) price trends of comparable listings on ZeroMargin, and
//  (b) a condition-based depreciation of the original price, if the seller provides it.
// To plug in an external web price source, add it in `externalTrend()` below.
const CONDITION_FACTOR = { new: 0.85, like_new: 0.7, good: 0.55, fair: 0.4 };

const median = (arr) => {
  const s = [...arr].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};

// eslint-disable-next-line no-unused-vars
async function externalTrend(title, category) {
  return null; // hook for a scraped / third-party price feed
}

export async function suggestPrice({ title, category, condition = 'good', originalPrice }) {
  const kws = keywordsOf(title);
  const filter = { status: { $ne: 'sold' } };
  if (category) filter.category = category;
  if (kws.length) filter.$or = kws.map((k) => ({ title: new RegExp(`\\b${k.replace(/[^a-z0-9]/g, '')}`, 'i') }));
  const comps = await Listing.find(filter).select('price').limit(50).lean();
  const compPrices = comps.map((c) => c.price).filter((p) => p > 0);

  const signals = [];
  if (originalPrice > 0) signals.push(originalPrice * (CONDITION_FACTOR[condition] ?? 0.55));
  if (compPrices.length >= 3) signals.push(median(compPrices));
  const ext = await externalTrend(title, category);
  if (ext) signals.push(ext);
  if (!signals.length) return { suggested: null, low: null, high: null, basedOn: 0 };

  const mid = signals.reduce((a, b) => a + b, 0) / signals.length;
  const round = (n) => Math.max(1, Math.round(n / 10) * 10 || Math.round(n));
  return { suggested: round(mid), low: round(mid * 0.85), high: round(mid * 1.15), basedOn: compPrices.length };
}
