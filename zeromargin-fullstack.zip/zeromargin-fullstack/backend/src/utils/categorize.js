// Slide 3: "Category auto-tagged". Simple keyword classifier - no external API needed.
const RULES = {
  Electronics: ['phone', 'iphone', 'laptop', 'macbook', 'tablet', 'ipad', 'headphone', 'earbud', 'airpods', 'camera', 'charger', 'monitor', 'keyboard', 'mouse', 'speaker', 'console', 'playstation', 'xbox', 'calculator', 'router', 'smartwatch', 'watch', 'tv', 'kindle'],
  Clothing: ['shirt', 'tshirt', 't-shirt', 'jeans', 'jacket', 'hoodie', 'dress', 'kurta', 'saree', 'shoes', 'sneakers', 'boots', 'coat', 'sweater', 'bag', 'backpack', 'lehenga', 'skirt', 'top'],
  Furniture: ['table', 'chair', 'desk', 'sofa', 'couch', 'bed', 'mattress', 'shelf', 'bookshelf', 'wardrobe', 'cupboard', 'stool', 'drawer'],
  Books: ['book', 'textbook', 'novel', 'notes', 'guide', 'edition', 'manual', 'comic', 'magazine'],
  'Home & Kitchen': ['kettle', 'mixer', 'grinder', 'cooker', 'microwave', 'fridge', 'refrigerator', 'toaster', 'lamp', 'fan', 'heater', 'utensil', 'pan', 'bucket', 'curtain', 'iron'],
  'Sports & Fitness': ['bat', 'ball', 'racket', 'racquet', 'cycle', 'bicycle', 'dumbbell', 'yoga', 'gym', 'skates', 'football', 'cricket', 'badminton', 'treadmill'],
};

const tokenize = (s) => (s || '').toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/).filter(Boolean);

export function categorize(title = '', description = '') {
  const words = tokenize(`${title} ${title} ${description}`); // title weighs double
  let best = 'Other';
  let bestScore = 0;
  const tags = new Set();
  for (const [cat, keys] of Object.entries(RULES)) {
    let score = 0;
    for (const w of words) {
      if (keys.includes(w)) {
        score += 1;
        tags.add(w);
      }
    }
    if (score > bestScore) {
      best = cat;
      bestScore = score;
    }
  }
  return { category: best, tags: [...tags].slice(0, 6) };
}

export const keywordsOf = (s) => tokenize(s).filter((w) => w.length > 2);
