import mongoose from 'mongoose';

// placed -> accepted -> handed_off -> completed (verified) | disputed (not verified)
const orderSchema = new mongoose.Schema(
  {
    listing: { type: mongoose.Schema.Types.ObjectId, ref: 'Listing', required: true },
    buyer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    seller: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    price: { type: Number, required: true },
    commission: { type: Number, default: 0 }, // always 0 - that's the point
    status: {
      type: String,
      enum: ['placed', 'accepted', 'handed_off', 'completed', 'disputed', 'cancelled'],
      default: 'placed',
    },
  },
  { timestamps: true }
);

export default mongoose.model('Order', orderSchema);
