import mongoose from 'mongoose';

export const CATEGORIES = ['Electronics', 'Clothing', 'Furniture', 'Books', 'Home & Kitchen', 'Sports & Fitness', 'Other'];
export const CONDITIONS = ['new', 'like_new', 'good', 'fair'];

const listingSchema = new mongoose.Schema(
  {
    seller: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, trim: true, maxlength: 2000, default: '' },
    price: { type: Number, required: true, min: 0 },
    originalPrice: { type: Number, min: 0 },
    suggestedPrice: { type: Number },
    category: { type: String, enum: CATEGORIES, default: 'Other', index: true },
    tags: [String],
    condition: { type: String, enum: CONDITIONS, default: 'good' },
    images: [String],
    city: { type: String, trim: true, default: '' },
    status: { type: String, enum: ['available', 'reserved', 'sold'], default: 'available', index: true },
  },
  { timestamps: true }
);
listingSchema.index({ title: 'text', description: 'text', tags: 'text' });

export default mongoose.model('Listing', listingSchema);
