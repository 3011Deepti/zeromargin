import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 60 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, select: false },
    college: { type: String, trim: true, default: '' },
    city: { type: String, trim: true, default: '' },
    verifiedTrades: { type: Number, default: 0 },
    disputedTrades: { type: Number, default: 0 },
  },
  { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } }
);

// Trust score = successful verified hand-offs / total completed orders (as a %)
userSchema.virtual('totalTrades').get(function () {
  return this.verifiedTrades + this.disputedTrades;
});
userSchema.virtual('trustScore').get(function () {
  const total = this.verifiedTrades + this.disputedTrades;
  return total === 0 ? null : Math.round((this.verifiedTrades / total) * 100);
});

export default mongoose.model('User', userSchema);
