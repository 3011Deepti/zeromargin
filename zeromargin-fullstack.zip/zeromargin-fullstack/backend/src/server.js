import 'dotenv/config';
import http from 'http';
import mongoose from 'mongoose';
import jwt from 'jsonwebtoken';
import { Server } from 'socket.io';
import app, { allowedOrigins } from './app.js';
import Conversation from './models/Conversation.js';
import { setIO } from './services/notify.js';
import { saveMessage } from './services/chat.js';

const { MONGO_URI, JWT_SECRET, PORT = 5000 } = process.env;
if (!MONGO_URI || !JWT_SECRET) {
  console.error('Missing MONGO_URI or JWT_SECRET. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: allowedOrigins() } });
setIO(io);

// Socket.io: real-time buyer-seller chat (no phone numbers are ever stored or shared)
io.use((socket, next) => {
  try {
    socket.userId = jwt.verify(socket.handshake.auth?.token, JWT_SECRET).id;
    next();
  } catch {
    next(new Error('unauthorized'));
  }
});
io.on('connection', (socket) => {
  socket.join(`user:${socket.userId}`);
  socket.on('chat:join', async (conversationId, ack) => {
    try {
      const c = await Conversation.findById(conversationId);
      if (!c || ![String(c.buyer), String(c.seller)].includes(String(socket.userId))) throw new Error('Not allowed');
      socket.join(`conv:${conversationId}`);
      ack?.({ ok: true });
    } catch (e) { ack?.({ ok: false, message: e.message }); }
  });
  socket.on('chat:send', async ({ conversationId, text }, ack) => {
    try { await saveMessage(conversationId, socket.userId, text); ack?.({ ok: true }); }
    catch (e) { ack?.({ ok: false, message: e.message }); }
  });
});

mongoose
  .connect(MONGO_URI)
  .then(() => server.listen(PORT, () => console.log(`ZeroMargin API running on :${PORT}`)))
  .catch((e) => { console.error('MongoDB connection failed:', e.message); process.exit(1); });
